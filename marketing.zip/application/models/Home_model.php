<?php
class Home_model extends CI_MODEL{
    
}